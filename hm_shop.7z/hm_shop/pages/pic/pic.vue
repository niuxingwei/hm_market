<template>
	<view class="pic">
		<scroll-view class="left" scroll-y>
			<view 
			@click="clickHandle(index,items.id)" 
			:class="active===index?'active':''" 
			v-for="(items,index) in kinds" 
			:key="items.id">
				{{items.title}}
			</view>
		</scroll-view>
		<scroll-view class="right" scroll-y>
			<view class="second" v-for="(items,index) in secondData" :key="index">
				<image @click="preview" src="https://t12.baidu.com/it/u=3032405654,396196190&fm=58"></image>
	             <text >{{items.title}}</text>
				 
			</view>
			<text v-if="secondData.length===0">暂无数据</text>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				kinds: [],
				active: 0,
				secondData:[]
			}
		},
		methods: {
			//获取图片分类
			async getPicsKind() {
				const res = await this.$myRequest({
					url: '/api/getimgcategory'
				})
				console.log(res.data.message)
				this.kinds = res.data.message
				this.clickHandle(0,this.kinds[0].id)
				console.log(this.kinds[0].id)
				
			},
			// 点击栏目高亮
			async clickHandle(index, id) {
				// console.log(id)
				this.active = index
				const res = await this.$myRequest({
					url: '/api/getimages/' + id
				})
				this.secondData=res.data.message
				
				console.log(res.data.message)
			},
			// 实现图片预览功能
			
		},
		onLoad() {
			this.getPicsKind()
		}
		
	}
</script>

<style lang="scss">
	page {
		height: 100%;
		
	}

	.pic {
		height: 100%;
		display: flex;
		.left {
			width: 200rpx;
			height: 100%;
			border-right: 1rpx solid #eee;

			view {
				height: 100rpx;
				padding-top: 20rpx;
				padding-bottom: 20rpx;
				line-height: 100rpx;
				text-align: center;
				font-size: 30rpx;
				color: #333333;
				border-bottom: 1rpx solid #eee;
			}

			.active {
				color: #FFFFFF;
				background-color: #B50E03;
			}
		}
		.right{
			width: 530rpx;
			height: 100%;
			margin: 0 auto;
			text{
				font-size: 30rpx;
				font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
				line-height: 40rpx;
			}
			.second{
				width: 500rpx;
				
			}
		}

	}
</style>
