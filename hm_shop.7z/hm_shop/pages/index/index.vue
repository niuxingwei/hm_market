<template>
	<view class="home">
		<swiper indicator-dots circular autoplay>
			<swiper-item v-for="item in swipers" :key="item.id">
				<image :src="item.img">
			</swiper-item>
		</swiper>


		<!-- 导航区 -->
		<view class="nav">
			<view class="nav-item" v-for="(items,index) in navs" :key="index" @click="navItem(items.path)">
				<view :class="items.icon"></view>
				<text> {{items.title}}</text>
			</view>
		</view>
		<!-- 推荐商品区 -->
		<view class="hot-goods">
			<view class="tit">推荐商品</view>
			<good :hotgoods="hotgoods"></good>
		</view>
	</view>

</template>

<script>
	import goodslist from '../../compoents/good-list/goodList.vue'
	export default {
		data() {
			return {
				swipers: [],
				hotgoods: [],
				navs:[
					{
						icon:'iconfont icon-chaoshi',
						title:'黑马超市',
						path:'/pages/goods/goods'
					},
					{
						icon:'iconfont icon-lianxiwomen',
						title:'联系我们',
						path:'/pages/contact/contact'
					},
					{
						icon:'iconfont icon-shangrenshequ_tupian',
						title:'社区图片',
						path:'/pages/pic/pic'
					},
					{
						icon:'iconfont icon-xuexishipin',
						title:'学习视频',
						path:'/pages/videos/videos'
					}
				]
			}
		},
		onLoad() {
			this.getSwipers()
			this.getHotGoods()
		},
		components:{
			"good":goodslist
		},
		methods: {
			//获取轮播图数据
			async getSwipers() {
				console.log('获取轮播图数据')
				const res = await this.$myRequest({
					url: '/api/getlunbo'
				})
				console.log(res)
				this.swipers = res.data.message
			},
			// 获取热门商品列表、
			async getHotGoods() {
				const res = await this.$myRequest({
					url: '/api/getgoods?pageindex=1'
				})
				console.log('热门商品')
				console.log(res)
				this.hotgoods = res.data.message
			},
			// 导航页面跳转
			navItem(url){
				console.log('出发点击事件')
				uni.navigateTo({
					url
				})
			}
		}
	}
</script>

<style lang="scss">
	.home {
		swiper {
			width: 750rpx;
			height: 380rpx;

			image {
				height: 100%;
				width: 100%;
			}
		}

		.nav {
			display: flex;

			.nav-item {
				width: 25%;
				text-align: center;

				text {
					font-size: 30rpx;
				}

				view {
					height: 120rpx;
					width: 120rpx;
					background-color: #FF0033;
					margin: 10rpx auto;
					border-radius: 60rpx;
					font-size: 60rpx;
					line-height: 120rpx;
					color: #FFFFFF;
				}
			}
		}

		.hot-goods {
			background-color: #eee;
			text-align: center;
			overflow: hidden;
			margin: 10rpx;

			.tit {
				letter-spacing: 20rpx;
				height: 50rpx;
				line-height: 50rpx;
				color: $shop-color;
				background-color: #FFFFFF;
				margin: 10rpx 0;
			}
		}

	}
</style>
