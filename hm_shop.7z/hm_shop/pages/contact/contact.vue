<template>
	<view class="contact">
		<image  class="img" src="http://www.itcast.cn/2018czydz/images/gywmban.jpg"></image>
		<view class="info">
			<view @click="phone">联系电话：{{phoneNumber}}</view>
			<view>校区地址：浙江省杭州市下沙经济开发区4号大街187号盛泰时代山</view>
		</view>
		<map class="map" :longitude="longitude" :latitude="latitude" :scale="scale" :markers="markers"></map>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				longitude: 116.34974,
				latitude:38.957902,
				scale:13,
				phoneNumber:'18511371251',
				markers:[
					{
						id:0,
						longitude: 116.34974,
						latitude:38.957902,
						iconPath:'../../static/icon/mapMarker.png',
						width:30,
						height:30
					}
				]
			}
		},
		methods: {
			// 点击拨打电话
			phone(){
				uni.makePhoneCall({
					phoneNumber:this.phoneNumber,
					success() {
						console.log('拨打成功')
					},
					fail() {
						console.log('拨打失败')
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.contact {
		.img {
			width: 750rpx;
			height: 320rpx;
		}

		.info {
			font-size: 30rpx;
			padding: 10rpx 20rpx;

			view {
				border-bottom: 1px solid #808080
			}
		}

		.map {
			width: 750rpx;
			height: 750rpx;
		}
	}
</style>
