<template>
	<view class="good_list">
		<good :hotgoods="good"></good>
		<view class="bottom" v-if="flag">-----我是有底线的-----</view>
	</view>
</template>

<script>
	import goodsList from '../../compoents/good-list/goodList.vue'
	export default {
		data() {
			return {
				pageindex: 1,
				good: [],
				flag: false
			}
		},
		methods: {
			// 获取商品列表
			async getGoodList(callBack) {
				const res = await this.$myRequest({
					url: '/api/getgoods?pageindex=' + this.pageindex
				})
				this.good = [...this.good, ...res.data.message]
				callBack&&callBack()
			}
		},
		components: {
			"good": goodsList
		},
		onReachBottom() {
			if (this.good.length < this.pageindex * 10) {
				return this.flag = true
			}
			this.pageindex++
			console.log('触底了'+this.pageindex)
			this.getGoodList()
		},
		onLoad() {
			this.getGoodList()
		},
		onPullDownRefresh() {
			this.pageindex = 1
			this.good = []
			this.flag=false
			setTimeout(() => {
				this.getGoodList(()=>{
					uni.stopPullDownRefresh()
				})
			}, 1000)
			console.log('下拉刷新')
		}
	}
</script>

<style lang="scss">
	.good_list {
		background-color: #eee;

		.bottom {
			text-align: center;
		}
	}
</style>
