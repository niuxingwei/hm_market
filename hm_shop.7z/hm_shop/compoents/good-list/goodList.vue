<template>
	<view class="good-list">
		<view class="good-item" v-for="items in hotgoods" :key="items.id">
			<image src="http://img95.699pic.com/desgin_photo/40079/4368_list.jpg!/fw/431/clip/0x300a0a0"></image>
			<view class="price">
				<text>{{items.sell_price}}</text>
				<text>{{items.market_price}}</text>
				<view class="good-name">{{items.title}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		props: ['hotgoods']
	}
</script>

<style lang="scss">
	
		.good-list {
			display: flex;
			flex-wrap: wrap;
			padding: 0 15rpx;
			justify-content: space-between;

			.good-item {
				background-color: #FFFFFF;
				width: 350rpx;
				margin-top: 10rpx;

				image {
					width: 80%;
					height: 150rpx;
				}

				.price {
					text {
						color: #B50E03;
					}

					text:nth-child(2) {
						margin-left: 5rpx;
						color: #808080;
						text-decoration: line-through;
						font-size: 15rpx;
					}

					.good-name {
						font-size: 20rpx;
					}
				}
			}
		}
	
</style>
